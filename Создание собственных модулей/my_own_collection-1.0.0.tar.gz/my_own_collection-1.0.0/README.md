#  Ansible Collection - my_own_namespace.yandex_cloud_elk

Содержит простой [модуль](https://github.com/Dimarkle/my_own_collection/blob/main/plugins/modules/my_own_module.py) создания файла.

Vars
------------
path - путь до файла.
content - содержимое файла. 


Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:


        - name: Test module
          hosts: localhost
          roles:
          - single_task_role
  
License
-------

MIT

Author Information
------------------

Diman
